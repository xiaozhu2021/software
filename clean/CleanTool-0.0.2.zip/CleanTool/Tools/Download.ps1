﻿"系统目录位于：$env:windir"
"默认安装程序目录位于：$env:ProgramFiles"
"当前日期:$(get-date)"
$code="null"
$text0='正在准备下载......'
$text0
$text1='正在下载，请稍后......'
$text1
"机器码：$code"
# 没有机器码！。
$dir= Split-Path -Parent $MyInvocation.MyCommand.Definition
cd $dir
$src = 'https://xiaozhu2007.github.io/f/hourong.txt'
$des = "$dir\Hourong.txt"
Invoke-WebRequest -uri $src -OutFile $des
Unblock-File $des

$src2 = 'https://xiaozhu2007.github.io/f/MyUninstall.exe'
$des2 = "$dir\MyUninstall.exe"
Invoke-WebRequest -uri $src2 -OutFile $des2
Unblock-File $des2
