﻿"系统目录位于：$env:windir"
"默认安装程序目录位于：$env:ProgramFiles"
"当前日期:$(get-date)"
$PID="null"
$text0='正在准备下载......'
$text0
$text1='正在下载，请稍后......'
$text1
"机器码：$PID"
$dir= Split-Path -Parent $MyInvocation.MyCommand.Definition
cd $dir
$src = 'https://xiaozhu2021.github.io/software/clean/f/hourong.txt'
$des = "$dir\Hourong.txt"
Invoke-WebRequest -uri $src -OutFile $des
Unblock-File $des
Start-Sleep -s 1

$src2 = 'https://xiaozhu2021.github.io/software/clean/f/MyUninstall.exe'
$des2 = "$dir\MyUninstall.exe"
Invoke-WebRequest -uri $src2 -OutFile $des2
Unblock-File $des2

$src3 = 'https://xiaozhu2021.github.io/software/clean/f/README.md'
$des3 = "$dir\README.md"
Invoke-WebRequest -uri $src3 -OutFile $des3
Unblock-File $des3
Start-Sleep -s 1

$text2='下载成功！正在清理更改并关闭......'
$text2
Start-Sleep -s 1
# 休眠一秒
exit
# 退出