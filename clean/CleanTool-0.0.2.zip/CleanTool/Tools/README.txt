请运行Download.ps1下载所需的文件！
具体运行方法：
右键>用PowerShell运行

--------------------

下载后有两个文件：
Hourong.txt
MyUninstall.exe

具体文件介绍：
Hourong.txt - 火绒下载地址
MyUninstall.exe - 强力卸载工具


=================English=================

Please run Download.ps1 Download the required files!
Specific operation method:
Right click > Run with PowerShell
--------------------

There are two files after downloading:

Hourong.txt
MyUninstall.exe

Specific documents:
Hourong.txt  - Download address of tinder
MyUninstall.exe  - Powerful unloading tool